function determinarDesempeno(nota) {
  if (nota >= 9.0) return { texto: "Excelente", clase: "cat-excelente" };
  if (nota >= 7.0) return { texto: "Bueno", clase: "cat-bueno" };
  if (nota >= 5.0) return { texto: "Regular", clase: "cat-regular" };
  return { texto: "Insuficiente", clase: "cat-insuficiente" };
}

const inputsPeso = document.querySelectorAll('.input-peso');
const sumaActualTexto = document.getElementById('sumaActualTexto');

function actualizarSumaEnTiempoReal() {
  let suma = 0;
  inputsPeso.forEach(input => {
    const valor = parseFloat(input.value);
    if (!isNaN(valor)) {
      suma += valor;
    }
  });
  sumaActualTexto.textContent = `${suma}%`;
}

inputsPeso.forEach(input => {
  input.addEventListener('input', actualizarSumaEnTiempoReal);
});

document.getElementById("btnCalcular").addEventListener("click", function() {
  const nombreColaborador = document.getElementById("nombre").value.trim();
  const cargoColaborador = document.getElementById("cargo").value.trim();
  const cajaErrores = document.getElementById("cajaErrores");
  const cajaResultado = document.getElementById("cajaResultado");

  let listaErrores = [];
  let sumatoriaPesos = 0;
  let notaFinal = 0;

  if (nombreColaborador === "") {
    listaErrores.push("El nombre del colaborador es obligatorio.");
  }
  if (cargoColaborador === "") {
    listaErrores.push("El cargo del colaborador es obligatorio.");
  }

  for (let i = 1; i <= 5; i++) {
    const puntajeValor = document.getElementById(`puntaje${i}`).value;
    const pesoValor = document.getElementById(`peso${i}`).value;
    
    const puntaje = parseFloat(puntajeValor);
    const peso = parseFloat(pesoValor);

    if (isNaN(puntaje) || puntaje < 1 || puntaje > 10) {
      listaErrores.push(`El puntaje del criterio ${i} debe estar entre 1 y 10.`);
    }

    if (isNaN(peso) || peso < 0 || peso > 100) {
      listaErrores.push(`El peso del criterio ${i} debe estar entre 0 y 100.`);
    } else {
      sumatoriaPesos += peso;
    }

    if (!isNaN(puntaje) && !isNaN(peso)) {
      notaFinal += (puntaje * peso) / 100;
    }
  }

  if (sumatoriaPesos !== 100 && listaErrores.length === 0) {
    listaErrores.push(`Los pesos deben sumar 100% (actual: ${sumatoriaPesos}%).`);
  } else if (sumatoriaPesos !== 100 && !listaErrores.some(e => e.includes("Los pesos deben sumar"))) {
     listaErrores.push(`Los pesos deben sumar 100% (actual: ${sumatoriaPesos}%).`);
  }

  if (listaErrores.length > 0) {
    cajaResultado.classList.add("oculto");
    
    let htmlErrores = "Corrige los siguientes errores:<ul>";
    for (let error of listaErrores) {
      htmlErrores += `<li>${error}</li>`;
    }
    htmlErrores += "</ul>";
    
    cajaErrores.innerHTML = htmlErrores;
    cajaErrores.classList.remove("oculto");
  } else {
    cajaErrores.classList.add("oculto");
    
    const resultado = determinarDesempeno(notaFinal);
    
    cajaResultado.className = resultado.clase; 
    cajaResultado.innerHTML = `
      <h3>Resultado de la Evaluación</h3>
      <p><strong>Colaborador:</strong> ${nombreColaborador}</p>
      <p><strong>Nota final:</strong> ${notaFinal.toFixed(2)}</p>
      <p><strong>Categoría:</strong> ${resultado.texto}</p>
    `;
    cajaResultado.classList.remove("oculto");
  }
});